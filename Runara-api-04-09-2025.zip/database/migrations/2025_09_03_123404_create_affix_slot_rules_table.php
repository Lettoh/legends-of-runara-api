<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('affix_slot_rules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('affix_id')->constrained('affixes')->cascadeOnDelete();
            $table->foreignId('slot_id')->constrained('equipment_slots')->cascadeOnDelete();
            $table->unique(['affix_id','slot_id']);
        });
    }
    public function down(): void {
        Schema::dropIfExists('affix_slot_rules');
    }
};
