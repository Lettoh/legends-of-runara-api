<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('equipment_slots', function (Blueprint $table) {
            $table->id();
            $table->string('code')->unique(); // weapon, offhand, helmet, chest, gloves, boots, ring, amulet, belt, cape
            $table->string('name');
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('equipment_slots');
    }
};
